/**
 * @fileoverview LevelBuilder - Constructs game levels from configuration objects.
 * Translates level definitions into IsoBoard entities (floor, objects, player).
 * @module game/levels/LevelBuilder
 */

/**
 * LevelBuilder - Instantiates levels from configuration data.
 * 
 * Responsible for:
 * - Creating floor tiles from 2D map data
 * - Placing stationary objects (conveyors, stations)
 * - Placing moveable objects (boxes)
 * - Validating win conditions
 * - Checking level completion criteria
 * 
 * @class LevelBuilder
 */
export class LevelBuilder {
    /**
     * Create a LevelBuilder instance.
     * 
     * @param {Phaser.Scene} scene - The Phaser scene
     * @param {IsoBoard} board - The isometric board to build on
     * @param {Object} [textureMap] - Mapping of logical names to texture keys
     * @param {Object} textureMap.floor - Floor tile config {key, frame}
     * @param {Object} textureMap.conveyor - Conveyor config {key, frame}
     * @param {Object} textureMap.robot - Robot config {key, frameOffset}
     * @param {Object} textureMap.box - Box config {key, frame}
     */
    constructor(scene, board, textureMap) {
        this.scene = scene;
        this.board = board;
        // Map logical strings ('floor', 'conveyor') to asset keys & frame indices
        this.textureMap = textureMap || {
            floor: { key: 'tiles', frame: 0 },
            robot: { key: 'robot', frameOffset: 0 }, // robot_type_1 (Row 0)
            box: { key: 'box', frame: 0 },
            conveyor: Array.from({ length: 6 }, (_, frame) => ({ key: 'conveyor', frame })), // conveyor frames 0-5
            pickup_zone: Array.from({ length: 4 }, (_, frame) => ({ key: 'pickup_zone', frame })), // pickup zone frames 0-3
            dropoff_zone: Array.from({ length: 4 }, (_, frame) => ({ key: 'dropoff_zone', frame })), // dropoff zone frames 0-3
            pillars: Array.from({ length: 4 }, (_, frame) => ({ key: 'pillars', frame })), // pillars frames 0-3
            walls: Array.from({ length: 2 }, (_, frame) => ({ key: 'walls', frame })), // walls frames 0-1
            shelves: Array.from({ length: 8 }, (_, frame) => ({ key: 'shelves', frame })), // shelves frames 0-7
        };
    }

    build(levelConfig) {
        // 1. Build Floor
        // The map data in config might be simplified (0 for empty, 1 for floor). 
        // We need to map that to actual texture frames.
        const floorData = levelConfig.map.data.map(row => 
            row.map(cellId => {
                // Assuming 1 = basic floor, 0 = empty hole
                return cellId === 1 ? this.textureMap.floor.frame : -1;
            })
        );
        
        this.board.createFloor(floorData, this.textureMap.floor.key);

        // 2. Place Stationary Objects
        if (levelConfig.objects && levelConfig.objects.stationary) {
            levelConfig.objects.stationary.forEach(obj => {
                if (obj.type === 'conveyor') {
                    // Conveyors are special Stationary Objects
                    // Use object's frame if specified, otherwise use default from textureMap
                    // Support conveyor as array
                    let conveyorKey, conveyorFrame;
                    if (Array.isArray(this.textureMap.conveyor)) {
                        conveyorKey = this.textureMap.conveyor[0].key;
                        conveyorFrame = obj.attributes?.frame !== undefined ? obj.attributes.frame : this.textureMap.conveyor[0].frame;
                    } else {
                        conveyorKey = this.textureMap.conveyor.key;
                        conveyorFrame = obj.attributes?.frame !== undefined ? obj.attributes.frame : this.textureMap.conveyor.frame;
                    }
                    const conv = this.board.addStationaryObject(obj.row, obj.col, conveyorKey, {
                        frame: conveyorFrame,
                        collidable: true, // Cannot walk on conveyor
                        isConveyor: true, // Mark as conveyor for game logic (for IsoBoard and win conditions)
                        attributes: { 
                            allowDrop: false,
                            id: obj.id, // e.g., 'input_1', 'output_1'
                            ...obj.attributes 
                        }
                    });
                } 
                else if (obj.type === 'pickup_zone' || obj.type === 'dropoff_zone') {
                    const textureArray = this.textureMap[obj.type];
                    const frameIndex = (obj.attributes?.frame ?? 0) % textureArray.length;
                    const zoneConfig = textureArray[frameIndex];
                    this.board.addStationaryObject(obj.row, obj.col, zoneConfig.key, {
                        frame: zoneConfig.frame,
                        collidable: false,
                        isZone: true,
                        attributes: {
                            allowDrop: false,
                            id: obj.id,
                            ...obj.attributes
                        }
                    });
                }
                else if (obj.type === 'pillars') {
                    const pillarConfig = this.textureMap.pillars[obj.attributes.frame % this.textureMap.pillars.length]; // Support pillars as array with frame selection
                    this.board.addStationaryObject(obj.row, obj.col, pillarConfig.key, {
                        frame: pillarConfig.frame,
                        collidable: true,
                        isPillar: true,
                        attributes: {
                            allowDrop: false,
                            id: obj.id,
                            ...obj.attributes
                        }
                    });
                }
                else if (obj.type === 'walls') {
                    const wallConfig = this.textureMap.walls[obj.attributes.frame % this.textureMap.walls.length];                    
                    const wallFrame = wallConfig.frame;
                    // Frame-specific Y offset to align both wall types
                    const wallYOffset = wallFrame === 0 ? 18 : wallFrame === 1 ? 0 : 18;
                    
                    this.board.addStationaryObject(obj.row, obj.col, wallConfig.key, {
                        frame: wallFrame,
                        collidable: false,
                        isWall: true,
                        visualOffsetX: -15, // Center the wider wall sprite horizontally
                        visualOffsetY: wallYOffset, // Frame-specific offset
                        attributes: {
                            allowDrop: false,
                            id: obj.id,
                            ...obj.attributes
                        }
                    });
                }
                else if (obj.type === 'shelves') {
                    const shelfConfig = this.textureMap.shelves[obj.attributes.frame % this.textureMap.shelves.length];
                    this.board.addStationaryObject(obj.row, obj.col, shelfConfig.key, {
                        frame: shelfConfig.frame,
                        collidable: true,
                        isShelf: true,
                        attributes: {
                            allowDrop: false,
                            id: obj.id,
                            ...obj.attributes
                        }
                    });
                }
                else if (obj.type === 'OilDrums') {
                    const drumConfig = this.textureMap.oilDrums[obj.attributes.frame % this.textureMap.oilDrums.length];
                    this.board.addStationaryObject(obj.row, obj.col, drumConfig.key, {
                        frame: drumConfig.frame,
                        collidable: true,
                        isOilDrum: true,
                        attributes: {
                            allowDrop: false,
                            id: obj.id,
                            ...obj.attributes
                        }
                    });
                }
            });
        }

        // 3. Place Moveable Objects (Boxes)
        if (levelConfig.objects && levelConfig.objects.moveable) {
            levelConfig.objects.moveable.forEach(obj => {
                if (obj.type === 'box') {
                    // Box Fixes: Bigger (scale 1.5) and Nudge NE (x+3, y-4)
                    const box = this.board.addMoveableObject(obj.row, obj.col, this.textureMap.box.key, {
                        frame: this.textureMap.box.frame,
                        scale: 1.25,
                        visualOffsetX: 3,
                        visualOffsetY: -12, // Adjusted: was -4, minus 8 for partial base tileHeight/2 offset
                        zHeight: 12, // Ensure it clears the conveyor
                        pickupable: true, // Explicitly mark as pickupable
                        attributes: { 
                            id: obj.id,
                            ...obj.attributes 
                        }
                    });
                    // Important: Link the ID to the object for win condition checking
                    box.id = obj.id; 
                    box.isoType = 'box'; // Explicit Type for Blockly
                }
            });
        }
        
        // 4. Return Player Config (Scene will instantiate Player to keep control separate)
        return levelConfig.player;
    }
}
